1:"$Sreact.fragment"
2:I[28025,["/_next/static/chunks/0040bd455d712982.js","/_next/static/chunks/af0de1dde1af7218.js"],"default"]
3:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/247eb132b7f7b574.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"OzB3FVqCIQ1F35xGTOWwg","rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/0040bd455d712982.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/af0de1dde1af7218.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
