1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/247eb132b7f7b574.js"],"OutletBoundary"]
3:"$Sreact.suspense"
0:{"buildId":"OzB3FVqCIQ1F35xGTOWwg","rsc":["$","$1","c",{"children":[["$","div",null,{"style":{"height":"100vh","display":"flex","flexDirection":"column","justifyContent":"center","alignItems":"center","background":"#eeededff","color":"black","fontFamily":"sans-serif"},"children":[["$","h1",null,{"style":{"fontSize":"4rem","marginBottom":"1rem"},"children":"404"}],["$","p",null,{"style":{"fontSize":"1.3rem","marginBottom":"2rem","opacity":0.8},"children":"Oops… This page doesn’t exist."}],["$","a",null,{"href":"/","style":{"padding":"0.7rem 1.4rem","background":"black","color":"white","borderRadius":"6px","textDecoration":"none","fontWeight":600},"children":"Go Home"}]]}],null,["$","$L2",null,{"children":["$","$3",null,{"name":"Next.MetadataOutlet","children":"$@4"}]}]]}],"loading":null,"isPartial":false}
4:null
