(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_0f36e103._.js",
  "static/chunks/node_modules_b644b2b2._.js"
],
    source: "dynamic"
});
