(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_48acafc9._.js",
  "static/chunks/node_modules_5ca3da3d._.js",
  "static/chunks/src_component_spinner_spinner_module_24ad2622.css"
],
    source: "dynamic"
});
