(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_94ce43b8._.js",
  "static/chunks/node_modules_0b9b81a4._.js"
],
    source: "dynamic"
});
