module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[project]/src/api/authentication/data:fd3dcc [app-ssr] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"60f32a95af126a69a3ff3d11fb1622ba1db49a1e75":"default"},"src/api/authentication/login.ts",""] */ __turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("60f32a95af126a69a3ff3d11fb1622ba1db49a1e75", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "default");
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vbG9naW4udHMiXSwic291cmNlc0NvbnRlbnQiOlsiXCJ1c2Ugc2VydmVyXCI7XHJcbmltcG9ydCB7IFJlcXVlc3RMb2dpbkRhdGEsIFJlc3BvbnNlTG9naW5EYXRhIH0gZnJvbSBcIi4uL3R5cGVzL2xvZ2luXCI7XHJcbmltcG9ydCB7IHBvc3RSZXF1ZXN0IH0gZnJvbSBcIi4vbWFpblwiO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgZnVuY3Rpb24gTG9naW5BcGkoZGF0YTogUmVxdWVzdExvZ2luRGF0YSwgdG9rZW4/OiBzdHJpbmcpIHtcclxuICBjb25zdCBjdXN0b21IZWFkZXI6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7fTtcclxuICBpZiAodG9rZW4pIGN1c3RvbUhlYWRlci5BdXRob3JpemF0aW9uID0gYEJlYXJlciAke3Rva2VufWA7XHJcblxyXG4gIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgcG9zdFJlcXVlc3QoYC9hcGkvU2VsbGVyL0xvZ2luYCwgZGF0YSwgY3VzdG9tSGVhZGVyKTtcclxuICBpZiAocmVzcG9uc2Uuc3VjY2Vzcykge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgZGF0YTogcmVzcG9uc2UuZGF0YSBhcyBSZXNwb25zZUxvZ2luRGF0YSxcclxuICAgICAgc3RhdHVzOiByZXNwb25zZS5zdGF0dXMsXHJcbiAgICAgIG1lc3NhZ2U6IFwiTG9naW4gc3VjY2Vzc2Z1bFwiLFxyXG4gICAgfTtcclxuICB9XHJcblxyXG4gIGNvbnN0IHN0YXR1cyA9IHJlc3BvbnNlLnN0YXR1cztcclxuXHJcbiAgaWYgKHN0YXR1cyA9PT0gNDAwIHx8IHN0YXR1cyA9PT0gNDAxKSB7XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBkYXRhOiBudWxsLFxyXG4gICAgICBtZXNzYWdlOiBcIkludmFsaWQgY3JlZGVudGlhbHNcIixcclxuICAgICAgc3RhdHVzLFxyXG4gICAgfTtcclxuICB9XHJcblxyXG4gIHJldHVybiB7XHJcbiAgICBkYXRhOiBudWxsLFxyXG4gICAgbWVzc2FnZTogcmVzcG9uc2UubWVzc2FnZSB8fCBcIkxvZ2luIGZhaWxlZCBkdWUgdG8gYW4gdW5leHBlY3RlZCBlcnJvci5cIixcclxuICAgIHN0YXR1czogcmVzcG9uc2Uuc3RhdHVzLFxyXG4gIH07XHJcblxyXG4gIC8vIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgcG9zdFJlcXVlc3QoYC9hcGkvU2VsbGVyL0xvZ2luYCwgZGF0YSk7XHJcblxyXG4gIC8vIGlmIChyZXNwb25zZS5zdWNjZXNzKSB7XHJcbiAgLy8gICByZXR1cm4ge1xyXG4gIC8vICAgICBkYXRhOiByZXNwb25zZS5kYXRhLFxyXG4gIC8vICAgICBtZXNzYWdlOiBcIkxvZ2luIHN1Y2Nlc3NmdWxcIixcclxuICAvLyAgIH07XHJcbiAgLy8gfVxyXG5cclxuICAvLyAvLyBIYW5kbGUgZXJyb3Igb2JqZWN0XHJcbiAgLy8gaWYgKHJlc3BvbnNlLmVycm9yKSB7XHJcbiAgLy8gICBpZiAoYXhpb3MuaXNBeGlvc0Vycm9yKHJlc3BvbnNlLmVycm9yKSkge1xyXG4gIC8vICAgICBjb25zdCBzdGF0dXMgPSByZXNwb25zZS5lcnJvci5yZXNwb25zZT8uc3RhdHVzO1xyXG5cclxuICAvLyAgICAgaWYgKHN0YXR1cyA9PT0gNDAwIHx8IHN0YXR1cyA9PT0gNDAxKSB7XHJcbiAgLy8gICAgICAgcmV0dXJuIHtcclxuICAvLyAgICAgICAgIGRhdGE6IG51bGwsXHJcbiAgLy8gICAgICAgICBtZXNzYWdlOiBcIkludmFsaWQgY3JlZGVudGlhbHNcIixcclxuICAvLyAgICAgICB9O1xyXG4gIC8vICAgICB9XHJcbiAgLy8gICAgIHJldHVybiB7XHJcbiAgLy8gICAgICAgZGF0YTogbnVsbCxcclxuICAvLyAgICAgICBtZXNzYWdlOlxyXG4gIC8vICAgICAgICAgcmVzcG9uc2UuZXJyb3IucmVzcG9uc2U/LmRhdGEgfHwgXCJBbiBlcnJvciBvY2N1cnJlZCBkdXJpbmcgbG9naW4uXCIsXHJcbiAgLy8gICAgIH07XHJcbiAgLy8gICB9XHJcblxyXG4gIC8vICAgLy8gRm9yIHVua25vd24gZXJyb3IgdHlwZXNcclxuICAvLyAgIHJldHVybiB7XHJcbiAgLy8gICAgIGRhdGE6IG51bGwsXHJcbiAgLy8gICAgIG1lc3NhZ2U6IFwiQW4gdW5leHBlY3RlZCBlcnJvciBvY2N1cnJlZCBkdXJpbmcgbG9naW4uXCIsXHJcbiAgLy8gICB9O1xyXG4gIC8vIH1cclxuXHJcbiAgLy8gLy8gSWYgbm8gZXJyb3IgaW5mbywgZ2VuZXJpYyBmYWxsYmFja1xyXG4gIC8vIHJldHVybiB7XHJcbiAgLy8gICBkYXRhOiBudWxsLFxyXG4gIC8vICAgbWVzc2FnZTogXCJBbiB1bmV4cGVjdGVkIGVycm9yIG9jY3VycmVkIGR1cmluZyBsb2dpbi5cIixcclxuICAvLyB9O1xyXG59XHJcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoib1NBSThCIn0=
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/api/authentication/data:aec771 [app-ssr] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"609cfb655693260240586dd588edc6f9764f60af79":"default"},"src/api/authentication/signup.ts",""] */ __turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("609cfb655693260240586dd588edc6f9764f60af79", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "default");
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vc2lnbnVwLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHNlcnZlclwiO1xyXG5pbXBvcnQgeyBTaWduVXBEYXRhIH0gZnJvbSBcIi4uL3R5cGVzL3NpZ251cFwiO1xyXG5pbXBvcnQgeyBwb3N0UmVxdWVzdCB9IGZyb20gXCIuL21haW5cIjtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGFzeW5jIGZ1bmN0aW9uIFNpZ25VcEFwaShkYXRhOiBTaWduVXBEYXRhLCB0b2tlbj86IHN0cmluZykge1xyXG4gIGNvbnN0IGN1c3RvbUhlYWRlcnM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7fTtcclxuICBpZiAodG9rZW4pIGN1c3RvbUhlYWRlcnMuQXV0aG9yaXphdGlvbiA9IGBCZWFyZXIgJHt0b2tlbn1gO1xyXG5cclxuICBjb25zdCByZXNwb25zZSA9IGF3YWl0IHBvc3RSZXF1ZXN0KGAvYXBpL1NlbGxlci9TaWduVXBgLCBkYXRhLCBjdXN0b21IZWFkZXJzKTtcclxuXHJcbiAgaWYgKHJlc3BvbnNlLnN1Y2Nlc3MpIHtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIGRhdGE6IHJlc3BvbnNlLmRhdGEsXHJcbiAgICAgIHN0YXR1czogcmVzcG9uc2Uuc3RhdHVzLFxyXG4gICAgICBtZXNzYWdlOiBcIlNpZ25VcCBzdWNjZXNzZnVsXCIsXHJcbiAgICB9O1xyXG4gIH1cclxuXHJcbiAgY29uc3Qgc3RhdHVzID0gcmVzcG9uc2Uuc3RhdHVzO1xyXG5cclxuICBpZiAoc3RhdHVzID09PSA0MDAgfHwgc3RhdHVzID09PSA0MDEpIHtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIGRhdGE6IG51bGwsXHJcbiAgICAgIG1lc3NhZ2U6IFwiSW52YWxpZCBjcmVkZW50aWFsc1wiLFxyXG4gICAgICBzdGF0dXMsXHJcbiAgICB9O1xyXG4gIH1cclxuXHJcbiAgaWYgKHN0YXR1cyA9PT0gNDA5KSB7XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBkYXRhOiBudWxsLFxyXG4gICAgICBtZXNzYWdlOiBcIkFjY291bnQgYWxyZWFkeSBleGlzdHNcIixcclxuICAgICAgc3RhdHVzLFxyXG4gICAgfTtcclxuICB9XHJcblxyXG4gIHJldHVybiB7XHJcbiAgICBkYXRhOiBudWxsLFxyXG4gICAgbWVzc2FnZTogcmVzcG9uc2UubWVzc2FnZSB8fCBcIlNpZ251cCBmYWlsZWQgZHVlIHRvIGFuIHVuZXhwZWN0ZWQgZXJyb3IuXCIsXHJcbiAgICBzdGF0dXM6IHJlc3BvbnNlLnN0YXR1cyxcclxuICB9O1xyXG59XHJcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoicVNBSThCIn0=
}),
"[project]/src/api/authentication/data:dcfb58 [app-ssr] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"401b2c145aa0f07f28d246ecf8d2f815e8885e2877":"default"},"src/api/authentication/sellerVerification.ts",""] */ __turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("401b2c145aa0f07f28d246ecf8d2f815e8885e2877", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "default");
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vc2VsbGVyVmVyaWZpY2F0aW9uLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHNlcnZlclwiO1xyXG5pbXBvcnQgeyBnZXRSZXF1ZXN0IH0gZnJvbSBcIi4vbWFpblwiO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgZnVuY3Rpb24gU2VsbGVyVmVyaWZpY2F0aW9uQXBpKHRva2VuOiBzdHJpbmcpIHtcclxuICBjb25zdCBjdXN0b21IZWFkZXJzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge307XHJcbiAgaWYgKHRva2VuKSBjdXN0b21IZWFkZXJzLkF1dGhvcml6YXRpb24gPSBgQmVhcmVyICR7dG9rZW59YDtcclxuICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGdldFJlcXVlc3QoXHJcbiAgICBgL2FwaS9TZWxsZXIvU2VsbGVyVmVyaWZpY2F0aW9uYCxcclxuICAgIG51bGwsXHJcbiAgICBjdXN0b21IZWFkZXJzXHJcbiAgKTtcclxuICBpZiAocmVzcG9uc2Uuc3VjY2Vzcykge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgZGF0YTogcmVzcG9uc2UuZGF0YSxcclxuICAgICAgc3RhdHVzOiByZXNwb25zZS5zdGF0dXMsXHJcbiAgICB9O1xyXG4gIH1cclxuICBjb25zdCBzdGF0dXMgPSByZXNwb25zZS5zdGF0dXM7XHJcblxyXG4gIGlmIChzdGF0dXMgPT09IDQwMCB8fCBzdGF0dXMgPT09IDQwMSkge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgZGF0YTogbnVsbCxcclxuICAgICAgbWVzc2FnZTogXCJJblZhbGlkIFRva2VuIFVzZXJcIixcclxuICAgICAgc3RhdHVzLFxyXG4gICAgfTtcclxuICB9XHJcblxyXG4gIGlmIChzdGF0dXMgPT09IDQwOSkge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgZGF0YTogbnVsbCxcclxuICAgICAgbWVzc2FnZTogXCJBY2NvdW50IGFscmVhZHkgVmVyaWZpZWRcIixcclxuICAgICAgc3RhdHVzLFxyXG4gICAgfTtcclxuICB9XHJcblxyXG4gIHJldHVybiB7XHJcbiAgICBkYXRhOiBudWxsLFxyXG4gICAgbWVzc2FnZTpcclxuICAgICAgcmVzcG9uc2UubWVzc2FnZSB8fCBcIlZlcmlmaWNhdGlvbiBmYWlsZWQgZHVlIHRvIGFuIHVuZXhwZWN0ZWQgZXJyb3IuXCIsXHJcbiAgICBzdGF0dXM6IHJlc3BvbnNlLnN0YXR1cyxcclxuICB9O1xyXG59XHJcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiaVRBRzhCIn0=
}),
"[project]/src/api/authentication/data:66c6b1 [app-ssr] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"407a9a3b4a857c3bdc862b44716ec41b902e6ec060":"default"},"src/api/authentication/OtpSend.ts",""] */ __turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("407a9a3b4a857c3bdc862b44716ec41b902e6ec060", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "default");
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vT3RwU2VuZC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBzZXJ2ZXJcIjtcclxuXHJcbmltcG9ydCB7IGdldFJlcXVlc3QgfSBmcm9tIFwiLi9tYWluXCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbiBPdHBTZW5kKHRva2VuOiBzdHJpbmcpIHtcclxuICBjb25zdCBjdXN0b21IZWFkZXJzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge307XHJcbiAgaWYgKHRva2VuKSBjdXN0b21IZWFkZXJzLkF1dGhvcml6YXRpb24gPSBgQmVhcmVyICR7dG9rZW59YDtcclxuICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGdldFJlcXVlc3QoXHJcbiAgICBgL2FwaS9TZWxsZXIvT1RQU2VuZFZpYUVtYWlsYCxcclxuICAgIG51bGwsXHJcbiAgICBjdXN0b21IZWFkZXJzXHJcbiAgKTtcclxuICBpZiAocmVzcG9uc2Uuc3VjY2Vzcykge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgZGF0YTogcmVzcG9uc2UuZGF0YSxcclxuICAgICAgc3RhdHVzOiByZXNwb25zZS5zdGF0dXMsXHJcbiAgICB9O1xyXG4gIH1cclxuICBjb25zdCBzdGF0dXMgPSByZXNwb25zZS5zdGF0dXM7XHJcblxyXG4gIGlmIChzdGF0dXMgPT09IDQwMCB8fCBzdGF0dXMgPT09IDQwMSkge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgZGF0YTogbnVsbCxcclxuICAgICAgbWVzc2FnZTogXCJDb3lsZCBOb3QgU2VuZCBPVFBcIixcclxuICAgICAgc3RhdHVzLFxyXG4gICAgfTtcclxuICB9XHJcblxyXG4gIGlmIChzdGF0dXMgPT09IDQwOSkge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgZGF0YTogbnVsbCxcclxuICAgICAgbWVzc2FnZTogXCJBY2NvdW50IGFscmVhZHkgZXhpc3RzXCIsXHJcbiAgICAgIHN0YXR1cyxcclxuICAgIH07XHJcbiAgfVxyXG5cclxuICByZXR1cm4ge1xyXG4gICAgZGF0YTogbnVsbCxcclxuICAgIG1lc3NhZ2U6XHJcbiAgICAgIHJlc3BvbnNlLm1lc3NhZ2UgfHwgXCJBdXRoZW50YWN0aW9uIGZhaWxlZCBkdWUgdG8gYW4gdW5leHBlY3RlZCBlcnJvci5cIixcclxuICAgIHN0YXR1czogcmVzcG9uc2Uuc3RhdHVzLFxyXG4gIH07XHJcbn1cclxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJzU0FJOEIifQ==
}),
"[project]/src/app/sellerlogin/page.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Login
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Eye$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/eye.js [app-ssr] (ecmascript) <export default as Eye>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2d$closed$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EyeClosed$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/eye-closed.js [app-ssr] (ecmascript) <export default as EyeClosed>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$authentication$2f$data$3a$fd3dcc__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/src/api/authentication/data:fd3dcc [app-ssr] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$authentication$2f$data$3a$aec771__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/src/api/authentication/data:aec771 [app-ssr] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$authentication$2f$data$3a$dcfb58__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/src/api/authentication/data:dcfb58 [app-ssr] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$authentication$2f$data$3a$66c6b1__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/src/api/authentication/data:66c6b1 [app-ssr] (ecmascript) <text/javascript>");
"use client";
;
;
;
;
;
;
;
;
function Login() {
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const [showPassword, setShowPassword] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showPassword1, setShowPassword1] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showList, setShowList] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [Email, setEmail] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [password, setPassword] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [UserNameSeller, setUserNameSeller] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [EmailSeller, setEmailSeller] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [passwordSeller, setPasswordSeller] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [passwordConfirm, setPasswordConfirm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [phoneNo, setphoneNo] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [responseBack, setResponseBack] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    const [createAccount, setCreateAccount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [errors, setErrors] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].useState({});
    const [storeList, setStoreList] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    //Login Function
    const Login = async ()=>{
        const formData = {
            Email,
            password
        };
        const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$authentication$2f$data$3a$fd3dcc__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["default"])(formData);
        console.log("Response from Login API:", response);
        if (response?.status === 200 || response?.status === 201) {
            setEmail("");
            setPassword("");
            setResponseBack(3);
            const token = response.data?.token;
            localStorage.setItem("token", token);
            verfiedSeller(String(token));
        }
        if (response?.status === 400 || response?.status === 401) {
            setResponseBack(1);
        }
    };
    const verfiy = async ()=>{
        const token = localStorage.getItem("token");
        const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$authentication$2f$data$3a$66c6b1__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["default"])(token);
        console.log("Response from VerifySeller API:", response);
    };
    const verfiedSeller = async (token)=>{
        const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$authentication$2f$data$3a$dcfb58__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["default"])(token);
        console.log("Response from SellerVerification API:", response.data);
        if (response.data === "UnVerified Seller") {
            verfiy();
            localStorage.setItem("userEmail", Email.toLowerCase());
            router.push("/sellerlogin/otpVerification");
        } else {
            setShowList(true);
            router.push("/mainDashboard");
        }
    };
    //SignUp Function
    const SignUp = async ()=>{
        var data = {
            userName: UserNameSeller,
            email: EmailSeller,
            phoneNo: phoneNo,
            password: passwordSeller
        };
        const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$authentication$2f$data$3a$aec771__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["default"])(data);
        console.log("Response from SignUp API:", response);
        if (response?.status === 200 || response?.status === 201) {
            setUserNameSeller("");
            setEmailSeller("");
            setphoneNo("");
            setPasswordSeller("");
            setPasswordConfirm("");
            setResponseBack(4);
            setCreateAccount(false);
        }
        if (response?.status === 400 || response?.status === 401) {
            setResponseBack(1);
        } else setResponseBack(2);
    };
    const validate = ()=>{
        let newErrors = {};
        if (phoneNo.length < 11) {
            newErrors.phoneNo = "Phone No must be at least 11 characters";
        }
        if (passwordSeller.length < 8) {
            newErrors.passwordSeller = "Password must be at least 8 characters";
        }
        if (passwordSeller !== passwordConfirm) {
            newErrors.passwordConfirm = "Passwords do not match";
        }
        setErrors(newErrors);
        if (Object.keys(newErrors).length === 0) {
            SignUp();
        }
        return newErrors;
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (responseBack === 1 || responseBack === 2 || responseBack === 3) {
            setTimeout(()=>{
                setResponseBack(0);
            }, 2000);
        }
    }, [
        responseBack
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex justify-center items-center min-h-screen bg-gray-100",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white shadow-lg rounded-lg p-6 w-full max-w-sm",
            children: createAccount ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-center text-2xl font-semibold mb-6",
                        children: "Sign Up"
                    }, void 0, false, {
                        fileName: "[project]/src/app/sellerlogin/page.tsx",
                        lineNumber: 130,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        htmlFor: "email",
                                        className: "block text-sm font-medium text-gray-700 mb-1",
                                        children: "UserName"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/sellerlogin/page.tsx",
                                        lineNumber: 135,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "Email",
                                        id: "email",
                                        value: UserNameSeller,
                                        onChange: (e)=>setUserNameSeller(e.target.value),
                                        className: "w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500",
                                        placeholder: "UserName",
                                        required: true
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/sellerlogin/page.tsx",
                                        lineNumber: 141,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/sellerlogin/page.tsx",
                                lineNumber: 134,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        htmlFor: "email",
                                        className: "block text-sm font-medium text-gray-700 mb-1",
                                        children: "Email"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/sellerlogin/page.tsx",
                                        lineNumber: 152,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "Email",
                                        id: "email",
                                        value: EmailSeller,
                                        onChange: (e)=>setEmailSeller(e.target.value),
                                        className: "w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500",
                                        placeholder: "Email",
                                        required: true
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/sellerlogin/page.tsx",
                                        lineNumber: 158,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/sellerlogin/page.tsx",
                                lineNumber: 151,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        htmlFor: "email",
                                        className: "block text-sm font-medium text-gray-700 mb-1",
                                        children: "Phone No"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/sellerlogin/page.tsx",
                                        lineNumber: 169,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "text",
                                        value: phoneNo,
                                        onChange: (e)=>setphoneNo(e.target.value),
                                        className: "w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500",
                                        placeholder: "Phone No",
                                        minLength: 11,
                                        required: true
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/sellerlogin/page.tsx",
                                        lineNumber: 175,
                                        columnNumber: 17
                                    }, this),
                                    errors.phoneNo && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-red-500 text-sm",
                                        children: errors.phoneNo
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/sellerlogin/page.tsx",
                                        lineNumber: 185,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/sellerlogin/page.tsx",
                                lineNumber: 168,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        htmlFor: "password",
                                        className: "block text-sm font-medium text-gray-700 mb-1",
                                        children: "Password"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/sellerlogin/page.tsx",
                                        lineNumber: 191,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "relative",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                value: passwordSeller,
                                                onChange: (e)=>setPasswordSeller(e.target.value),
                                                type: showPassword ? "text" : "password",
                                                id: "password",
                                                className: "w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 pr-10",
                                                placeholder: "Password",
                                                minLength: 8,
                                                required: true
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/sellerlogin/page.tsx",
                                                lineNumber: 198,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                className: "absolute right-2 top-1/2 transform -translate-y-1/2 text-blue-500 hover:text-blue-700",
                                                onClick: ()=>setShowPassword((prev)=>!prev),
                                                tabIndex: -1,
                                                children: showPassword ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Eye$3e$__["Eye"], {}, void 0, false, {
                                                    fileName: "[project]/src/app/sellerlogin/page.tsx",
                                                    lineNumber: 215,
                                                    columnNumber: 37
                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2d$closed$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EyeClosed$3e$__["EyeClosed"], {}, void 0, false, {
                                                    fileName: "[project]/src/app/sellerlogin/page.tsx",
                                                    lineNumber: 215,
                                                    columnNumber: 47
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/sellerlogin/page.tsx",
                                                lineNumber: 209,
                                                columnNumber: 19
                                            }, this),
                                            errors.passwordSeller && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-red-500 text-sm",
                                                children: errors.passwordSeller
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/sellerlogin/page.tsx",
                                                lineNumber: 218,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/sellerlogin/page.tsx",
                                        lineNumber: 197,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/sellerlogin/page.tsx",
                                lineNumber: 190,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        htmlFor: "password",
                                        className: "block text-sm font-medium text-gray-700 mb-1",
                                        children: "Confirm Password"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/sellerlogin/page.tsx",
                                        lineNumber: 225,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "relative",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                value: passwordConfirm,
                                                onChange: (e)=>setPasswordConfirm(e.target.value),
                                                type: showPassword1 ? "text" : "password",
                                                id: "password",
                                                className: "w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 pr-10",
                                                placeholder: "Confirm Password",
                                                required: true
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/sellerlogin/page.tsx",
                                                lineNumber: 232,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                className: "absolute right-2 top-1/2 transform -translate-y-1/2 text-blue-500 hover:text-blue-700",
                                                onClick: ()=>setShowPassword1((prev)=>!prev),
                                                tabIndex: -1,
                                                children: showPassword1 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Eye$3e$__["Eye"], {}, void 0, false, {
                                                    fileName: "[project]/src/app/sellerlogin/page.tsx",
                                                    lineNumber: 247,
                                                    columnNumber: 38
                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2d$closed$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EyeClosed$3e$__["EyeClosed"], {}, void 0, false, {
                                                    fileName: "[project]/src/app/sellerlogin/page.tsx",
                                                    lineNumber: 247,
                                                    columnNumber: 48
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/sellerlogin/page.tsx",
                                                lineNumber: 241,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/sellerlogin/page.tsx",
                                        lineNumber: 231,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/sellerlogin/page.tsx",
                                lineNumber: 224,
                                columnNumber: 15
                            }, this),
                            errors.passwordConfirm && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-red-500 text-sm",
                                children: errors.passwordConfirm
                            }, void 0, false, {
                                fileName: "[project]/src/app/sellerlogin/page.tsx",
                                lineNumber: 252,
                                columnNumber: 17
                            }, this),
                            responseBack === 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-full bg-red-100 text-red-800 text-center px-4 py-3 mb-2 rounded",
                                children: "Invalid Email/password"
                            }, void 0, false, {
                                fileName: "[project]/src/app/sellerlogin/page.tsx",
                                lineNumber: 255,
                                columnNumber: 17
                            }, this),
                            responseBack === 2 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-full bg-red-100 text-red-800 text-center px-4 py-3 mb-2 rounded",
                                children: "Network Error"
                            }, void 0, false, {
                                fileName: "[project]/src/app/sellerlogin/page.tsx",
                                lineNumber: 260,
                                columnNumber: 17
                            }, this),
                            responseBack === 4 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-full bg-red-100 text-red-800 text-center px-4 py-3 mb-2 rounded",
                                children: "SignUp Successful! Please Login."
                            }, void 0, false, {
                                fileName: "[project]/src/app/sellerlogin/page.tsx",
                                lineNumber: 265,
                                columnNumber: 17
                            }, this),
                            passwordSeller !== passwordConfirm ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                disabled: true,
                                className: "w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 transition duration-200 cursor-not-allowed",
                                children: "SignUp"
                            }, void 0, false, {
                                fileName: "[project]/src/app/sellerlogin/page.tsx",
                                lineNumber: 270,
                                columnNumber: 17
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>{
                                    validate();
                                },
                                className: "w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 transition duration-200 cursor-pointer",
                                children: "SignUp"
                            }, void 0, false, {
                                fileName: "[project]/src/app/sellerlogin/page.tsx",
                                lineNumber: 278,
                                columnNumber: 17
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                onClick: ()=>setCreateAccount(!createAccount),
                                className: "text-blue-500 text-sm hover:underline mt-2 cursor-pointer",
                                children: "Already Have an Account?"
                            }, void 0, false, {
                                fileName: "[project]/src/app/sellerlogin/page.tsx",
                                lineNumber: 288,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/sellerlogin/page.tsx",
                        lineNumber: 132,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-center text-2xl font-semibold mb-6",
                        children: "Login"
                    }, void 0, false, {
                        fileName: "[project]/src/app/sellerlogin/page.tsx",
                        lineNumber: 298,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        htmlFor: "email",
                                        className: "block text-sm font-medium text-gray-700 mb-1",
                                        children: "Email"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/sellerlogin/page.tsx",
                                        lineNumber: 303,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "Email",
                                        id: "email",
                                        value: Email,
                                        onChange: (e)=>setEmail(e.target.value),
                                        className: "w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500",
                                        placeholder: "Email",
                                        required: true
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/sellerlogin/page.tsx",
                                        lineNumber: 309,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/sellerlogin/page.tsx",
                                lineNumber: 302,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        htmlFor: "password",
                                        className: "block text-sm font-medium text-gray-700 mb-1",
                                        children: "Password"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/sellerlogin/page.tsx",
                                        lineNumber: 322,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "relative",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                value: password,
                                                onChange: (e)=>setPassword(e.target.value),
                                                type: showPassword ? "text" : "password",
                                                id: "password",
                                                className: "w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 pr-10",
                                                placeholder: "Password",
                                                required: true
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/sellerlogin/page.tsx",
                                                lineNumber: 329,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                className: "absolute right-2 top-1/2 transform -translate-y-1/2 text-blue-500 hover:text-blue-700",
                                                onClick: ()=>setShowPassword((prev)=>!prev),
                                                tabIndex: -1,
                                                children: showPassword ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Eye$3e$__["Eye"], {}, void 0, false, {
                                                    fileName: "[project]/src/app/sellerlogin/page.tsx",
                                                    lineNumber: 344,
                                                    columnNumber: 37
                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2d$closed$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EyeClosed$3e$__["EyeClosed"], {}, void 0, false, {
                                                    fileName: "[project]/src/app/sellerlogin/page.tsx",
                                                    lineNumber: 344,
                                                    columnNumber: 47
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/sellerlogin/page.tsx",
                                                lineNumber: 338,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/sellerlogin/page.tsx",
                                        lineNumber: 328,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/sellerlogin/page.tsx",
                                lineNumber: 321,
                                columnNumber: 15
                            }, this),
                            responseBack === 3 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-full bg-green-100 text-green-800 text-center px-4 py-3 mb-2 rounded",
                                children: "UserLogin Successful"
                            }, void 0, false, {
                                fileName: "[project]/src/app/sellerlogin/page.tsx",
                                lineNumber: 349,
                                columnNumber: 17
                            }, this),
                            responseBack === 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-full bg-red-100 text-red-800 text-center px-4 py-3 mb-2 rounded",
                                children: "Invalid Email/password"
                            }, void 0, false, {
                                fileName: "[project]/src/app/sellerlogin/page.tsx",
                                lineNumber: 354,
                                columnNumber: 17
                            }, this),
                            responseBack === 2 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-full bg-red-100 text-red-800 text-center px-4 py-3 mb-2 rounded",
                                children: "Network Error"
                            }, void 0, false, {
                                fileName: "[project]/src/app/sellerlogin/page.tsx",
                                lineNumber: 359,
                                columnNumber: 17
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "submit",
                                onClick: Login,
                                className: "w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 transition duration-200",
                                children: "Login"
                            }, void 0, false, {
                                fileName: "[project]/src/app/sellerlogin/page.tsx",
                                lineNumber: 363,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                onClick: ()=>setCreateAccount(!createAccount),
                                className: "text-blue-500 text-sm hover:underline mt-2 cursor-pointer",
                                children: "Create an Accont?"
                            }, void 0, false, {
                                fileName: "[project]/src/app/sellerlogin/page.tsx",
                                lineNumber: 370,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/sellerlogin/page.tsx",
                        lineNumber: 300,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true)
        }, void 0, false, {
            fileName: "[project]/src/app/sellerlogin/page.tsx",
            lineNumber: 127,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/sellerlogin/page.tsx",
        lineNumber: 126,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__097150bb._.js.map