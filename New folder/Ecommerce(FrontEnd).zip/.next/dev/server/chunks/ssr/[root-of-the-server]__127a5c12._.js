module.exports = [
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/https [external] (https, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[externals]/http2 [external] (http2, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http2", () => require("http2"));

module.exports = mod;
}),
"[externals]/assert [external] (assert, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("assert", () => require("assert"));

module.exports = mod;
}),
"[externals]/tty [external] (tty, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("tty", () => require("tty"));

module.exports = mod;
}),
"[externals]/os [external] (os, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("os", () => require("os"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[externals]/events [external] (events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}),
"[project]/src/api/authentication/main.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "getRequest",
    ()=>getRequest,
    "postRequest",
    ()=>postRequest
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-rsc] (ecmascript)");
;
const api = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"].create({
    baseURL: process.env.BASE_URL || "http://localhost:8081",
    headers: {
        "Content-Type": "application/json"
    },
    withCredentials: false
});
async function getRequest(url, params, headers) {
    try {
        const response = await api.get(url, {
            params,
            headers: {
                ...headers
            }
        });
        console.log(process.env.BASE_URL);
        return {
            success: true,
            data: response.data,
            status: response.status,
            message: "Request successful"
        };
    } catch (error) {
        console.error("GET request error:", error);
        return {
            success: false,
            error: error?.response?.data || error.message,
            status: error?.response?.status,
            message: "Request failed"
        };
    }
}
async function postRequest(url, data, headers) {
    try {
        const response = await api.post(url, data, {
            headers
        });
        return {
            success: true,
            data: response.data,
            status: response.status,
            message: "Request successful"
        };
    } catch (error) {
        console.error("Post request error:", error);
        return {
            success: false,
            error: error?.response?.data || error.message,
            status: error?.response?.status,
            message: "Request failed"
        };
    }
}
const __TURBOPACK__default__export__ = api;
;
}),
"[project]/src/api/authentication/login.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"60f32a95af126a69a3ff3d11fb1622ba1db49a1e75":"default"},"",""] */ __turbopack_context__.s([
    "default",
    ()=>LoginApi
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/server-reference.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$authentication$2f$main$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/authentication/main.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-validate.js [app-rsc] (ecmascript)");
;
;
async function LoginApi(data, token) {
    const customHeader = {};
    if (token) customHeader.Authorization = `Bearer ${token}`;
    const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$authentication$2f$main$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["postRequest"])(`/api/Seller/Login`, data, customHeader);
    if (response.success) {
        return {
            data: response.data,
            status: response.status,
            message: "Login successful"
        };
    }
    const status = response.status;
    if (status === 400 || status === 401) {
        return {
            data: null,
            message: "Invalid credentials",
            status
        };
    }
    return {
        data: null,
        message: response.message || "Login failed due to an unexpected error.",
        status: response.status
    };
// const response = await postRequest(`/api/Seller/Login`, data);
// if (response.success) {
//   return {
//     data: response.data,
//     message: "Login successful",
//   };
// }
// // Handle error object
// if (response.error) {
//   if (axios.isAxiosError(response.error)) {
//     const status = response.error.response?.status;
//     if (status === 400 || status === 401) {
//       return {
//         data: null,
//         message: "Invalid credentials",
//       };
//     }
//     return {
//       data: null,
//       message:
//         response.error.response?.data || "An error occurred during login.",
//     };
//   }
//   // For unknown error types
//   return {
//     data: null,
//     message: "An unexpected error occurred during login.",
//   };
// }
// // If no error info, generic fallback
// return {
//   data: null,
//   message: "An unexpected error occurred during login.",
// };
}
;
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ensureServerEntryExports"])([
    LoginApi
]);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(LoginApi, "60f32a95af126a69a3ff3d11fb1622ba1db49a1e75", null);
}),
"[project]/src/api/authentication/signup.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"609cfb655693260240586dd588edc6f9764f60af79":"default"},"",""] */ __turbopack_context__.s([
    "default",
    ()=>SignUpApi
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/server-reference.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$authentication$2f$main$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/authentication/main.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-validate.js [app-rsc] (ecmascript)");
;
;
async function SignUpApi(data, token) {
    const customHeaders = {};
    if (token) customHeaders.Authorization = `Bearer ${token}`;
    const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$authentication$2f$main$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["postRequest"])(`/api/Seller/SignUp`, data, customHeaders);
    if (response.success) {
        return {
            data: response.data,
            status: response.status,
            message: "SignUp successful"
        };
    }
    const status = response.status;
    if (status === 400 || status === 401) {
        return {
            data: null,
            message: "Invalid credentials",
            status
        };
    }
    if (status === 409) {
        return {
            data: null,
            message: "Account already exists",
            status
        };
    }
    return {
        data: null,
        message: response.message || "Signup failed due to an unexpected error.",
        status: response.status
    };
}
;
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ensureServerEntryExports"])([
    SignUpApi
]);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(SignUpApi, "609cfb655693260240586dd588edc6f9764f60af79", null);
}),
"[project]/src/api/authentication/sellerVerification.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"401b2c145aa0f07f28d246ecf8d2f815e8885e2877":"default"},"",""] */ __turbopack_context__.s([
    "default",
    ()=>SellerVerificationApi
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/server-reference.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$authentication$2f$main$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/authentication/main.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-validate.js [app-rsc] (ecmascript)");
;
;
async function SellerVerificationApi(token) {
    const customHeaders = {};
    if (token) customHeaders.Authorization = `Bearer ${token}`;
    const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$authentication$2f$main$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getRequest"])(`/api/Seller/SellerVerification`, null, customHeaders);
    if (response.success) {
        return {
            data: response.data,
            status: response.status
        };
    }
    const status = response.status;
    if (status === 400 || status === 401) {
        return {
            data: null,
            message: "InValid Token User",
            status
        };
    }
    if (status === 409) {
        return {
            data: null,
            message: "Account already Verified",
            status
        };
    }
    return {
        data: null,
        message: response.message || "Verification failed due to an unexpected error.",
        status: response.status
    };
}
;
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ensureServerEntryExports"])([
    SellerVerificationApi
]);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(SellerVerificationApi, "401b2c145aa0f07f28d246ecf8d2f815e8885e2877", null);
}),
"[project]/src/api/authentication/OtpSend.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"407a9a3b4a857c3bdc862b44716ec41b902e6ec060":"default"},"",""] */ __turbopack_context__.s([
    "default",
    ()=>OtpSend
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/server-reference.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$authentication$2f$main$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/authentication/main.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-validate.js [app-rsc] (ecmascript)");
;
;
async function OtpSend(token) {
    const customHeaders = {};
    if (token) customHeaders.Authorization = `Bearer ${token}`;
    const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$authentication$2f$main$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getRequest"])(`/api/Seller/OTPSendViaEmail`, null, customHeaders);
    if (response.success) {
        return {
            data: response.data,
            status: response.status
        };
    }
    const status = response.status;
    if (status === 400 || status === 401) {
        return {
            data: null,
            message: "Coyld Not Send OTP",
            status
        };
    }
    if (status === 409) {
        return {
            data: null,
            message: "Account already exists",
            status
        };
    }
    return {
        data: null,
        message: response.message || "Authentaction failed due to an unexpected error.",
        status: response.status
    };
}
;
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ensureServerEntryExports"])([
    OtpSend
]);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(OtpSend, "407a9a3b4a857c3bdc862b44716ec41b902e6ec060", null);
}),
"[project]/.next-internal/server/app/sellerlogin/page/actions.js { ACTIONS_MODULE0 => \"[project]/src/api/authentication/login.ts [app-rsc] (ecmascript)\", ACTIONS_MODULE1 => \"[project]/src/api/authentication/signup.ts [app-rsc] (ecmascript)\", ACTIONS_MODULE2 => \"[project]/src/api/authentication/sellerVerification.ts [app-rsc] (ecmascript)\", ACTIONS_MODULE3 => \"[project]/src/api/authentication/OtpSend.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$authentication$2f$login$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/authentication/login.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$authentication$2f$signup$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/authentication/signup.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$authentication$2f$sellerVerification$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/authentication/sellerVerification.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$authentication$2f$OtpSend$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/authentication/OtpSend.ts [app-rsc] (ecmascript)");
;
;
;
;
}),
"[project]/.next-internal/server/app/sellerlogin/page/actions.js { ACTIONS_MODULE0 => \"[project]/src/api/authentication/login.ts [app-rsc] (ecmascript)\", ACTIONS_MODULE1 => \"[project]/src/api/authentication/signup.ts [app-rsc] (ecmascript)\", ACTIONS_MODULE2 => \"[project]/src/api/authentication/sellerVerification.ts [app-rsc] (ecmascript)\", ACTIONS_MODULE3 => \"[project]/src/api/authentication/OtpSend.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "401b2c145aa0f07f28d246ecf8d2f815e8885e2877",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$authentication$2f$sellerVerification$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"],
    "407a9a3b4a857c3bdc862b44716ec41b902e6ec060",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$authentication$2f$OtpSend$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"],
    "609cfb655693260240586dd588edc6f9764f60af79",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$authentication$2f$signup$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"],
    "60f32a95af126a69a3ff3d11fb1622ba1db49a1e75",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$authentication$2f$login$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f$sellerlogin$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$src$2f$api$2f$authentication$2f$login$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE1__$3d3e$__$225b$project$5d2f$src$2f$api$2f$authentication$2f$signup$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE2__$3d3e$__$225b$project$5d2f$src$2f$api$2f$authentication$2f$sellerVerification$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE3__$3d3e$__$225b$project$5d2f$src$2f$api$2f$authentication$2f$OtpSend$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/sellerlogin/page/actions.js { ACTIONS_MODULE0 => "[project]/src/api/authentication/login.ts [app-rsc] (ecmascript)", ACTIONS_MODULE1 => "[project]/src/api/authentication/signup.ts [app-rsc] (ecmascript)", ACTIONS_MODULE2 => "[project]/src/api/authentication/sellerVerification.ts [app-rsc] (ecmascript)", ACTIONS_MODULE3 => "[project]/src/api/authentication/OtpSend.ts [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <locals>');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$authentication$2f$login$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/authentication/login.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$authentication$2f$signup$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/authentication/signup.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$authentication$2f$sellerVerification$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/authentication/sellerVerification.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$authentication$2f$OtpSend$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/authentication/OtpSend.ts [app-rsc] (ecmascript)");
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__127a5c12._.js.map